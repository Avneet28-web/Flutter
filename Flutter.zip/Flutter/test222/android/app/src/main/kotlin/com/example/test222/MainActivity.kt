package com.example.test222

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
