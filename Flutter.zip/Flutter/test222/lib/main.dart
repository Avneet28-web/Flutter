import 'package:flutter/material.dart';

void main() {
  runApp(const TravelApp());
}

class TravelApp extends StatelessWidget {
  const TravelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Travel Page',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueAccent),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false, // Removes debug banner
      home: const TravelPage(),
    );
  }
}

class TravelPage extends StatelessWidget {
  const TravelPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Travel Page'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Image at the top
          Image.asset(
            'assets/Toronto.jpg', // Updated to use local asset
            height: 250,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          const SizedBox(height: 10), // Spacing

          // Place name title
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              'DOWNTOWN TORONTO',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 10), // Spacing

          // Buttons for call, directions, and share
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButtonWithLabel(
                icon: Icons.call,
                label: 'Call',
                onPressed: () {
                  // Add functionality for call
                },
              ),
              IconButtonWithLabel(
                icon: Icons.directions,
                label: 'Route',
                onPressed: () {
                  // Add functionality for route
                },
              ),
              IconButtonWithLabel(
                icon: Icons.share,
                label: 'Share',
                onPressed: () {
                  // Add functionality for share
                },
              ),
            ],
          ),
          const SizedBox(height: 20), // Spacing

          // Description
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Text(
              'Discover the majestic beauty of the city. '
              'With breathtaking views, serene landscapes, and fun-filled streets, '
              'This destination is a paradise for nature enthusiasts and travelers alike.',
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.justify,
            ),
          ),
        ],
      ),
    );
  }
}

// Widget for buttons with icons and labels
class IconButtonWithLabel extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  const IconButtonWithLabel({
    super.key,
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IconButton(
          icon: Icon(icon, color: Colors.blueAccent),
          onPressed: onPressed,
        ),
        Text(
          label,
          style: const TextStyle(fontSize: 14, color: Colors.blueAccent),
        ),
      ],
    );
  }
}
